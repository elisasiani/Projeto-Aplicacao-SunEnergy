# Projeto-Aplica-o---SunEnergy
Projeto Institucional para a faculdade sobre energia renovável - Sistema que auxilia as empresas a gerenciar placas solares e oferece seus produtos a comunidade, juntamente com uma calculadora para simular os ganhos com o uso de uma placa solar.
